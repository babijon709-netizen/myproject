SRC by xdl_open, channel: t.me/dearvision

компилировать можно через aide или же если вы root user через скрипт compile.sh

Классы и методы которые нужно искать в дампе указаны.